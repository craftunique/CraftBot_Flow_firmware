2020.04.07 CraftFlow

Pr3dator  v1.1.23786
CraftGui  v1.1.5179
FlowAdmin V0.7.11

MAINBOARD & HMI-LCD:

New features:
- Languages have expanded ( FR, NL ).
- New sound menu - Now you are able to choose sound effects for different events.
- New personalized options menu - You can choose your preferences.
- New video player - Added buttons for convenient use.
- Case fan won’t be activated under 50C temp of the main board.

Bug fixes:
- Wifi password can not contain "SPACE" character. Fixed.
- Filament LOAD/UNLOAD slower than before. Fixed.
- Heat-up slower than before. Fixed.
- False online update indication. Fixed.


FlowAdmin :
- Remove some settings menu items
- Fix potential error display on first username/password change screen
- Text fixes