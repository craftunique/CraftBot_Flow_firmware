2020.06.12 CraftFlow

Pr3dator  v1.1.24276
CraftGui  v1.1.5863
FlowAdmin V0.7.21

Firmware:
Added: At the end of printing, the video continues to be recorded for a few seconds to prevent the video from ending abruptly.
Added: The system time and date can also be set offline in the timezone menu.
Added: The machine supports for EXFAT file systems on mounted media.
Added: The info menu has been expanded with the Report tab. Mesh level and status values can be saved to media.
Added: Startup wizard has been expanded with SMTP settings.
Added: Calibration menu has been expanded to sub-items.
Added: The machine performs an assisted bed measurement before printing. This can be enable or disable in the personalized menu.
Added: During printing when remove flash drive the machine goes pause state and a warning message appears in display.
Added: Extruder fan control frequency has modified (from 26 Khz to 150 kHz ). 
Fix: Minor bugs

FlowAdmin:
Fix: Minor bugs