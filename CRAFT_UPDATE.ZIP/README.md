2020.03.17 CraftFlow

Pr3dator  v1.1.23655
CraftGui  v1.1.4656
FlowAdmin V0.7.10

MAINBOARD & HMI-LCD:
New features:

- HU, DE, EN language packs.
- Separated filament flow setting in dual head machines.
- Separated LOAD/UNLOAD in IDEX machines.
- Better Z offset settings procedure in IDEX machines. 
  The XY position is centered in the middle of buildplate and the machine use Bl-touch in this process.
- Refactored print menu.
  File oparations in Print menu (under ACTIONS button). Delete, Copy , move , create new directory.



WEBSERVER:

New features:
- Printer status check from remote website.
- Better remote access service management and status check.
- Remote access token revoke option.
- Improved login session management.
- Idle detection and connection break when viewed through remote site.
- More aggressive default username / password update handling.

Bugfixes:
- IDEX head2 target temp set fix .
- Spelling errors and other minor fixes.